<?php
$db_base = "mysql:host=localhost;dbname=spk_smart";
$db_user = "root";
$db_pass = "";
$db = new PDO($db_base, $db_user, $db_pass);
?>